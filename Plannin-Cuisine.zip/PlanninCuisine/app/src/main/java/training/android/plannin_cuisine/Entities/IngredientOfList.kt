package training.android.plannin_cuisine.Entities

class IngredientOfList(val ingredientIt: Int, var quantity: Int)