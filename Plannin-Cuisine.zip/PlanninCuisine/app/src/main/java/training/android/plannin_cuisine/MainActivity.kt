package training.android.plannin_cuisine


import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.widget.Button
import training.android.plannin_cuisine.Database.App.Companion.database
import training.android.plannin_cuisine.Database.AppPreferences
import training.android.plannin_cuisine.Entities.*

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        if (!AppPreferences.firstRun) {

            creatAppIngredientList()
            creatAppUnitMeasure()
            createAppRecipies()
            database.createRecipeIngredient(RecipeIngredientList)

            AppPreferences.firstRun = true
            Log.d("SpinKotlin", "The value of our pref is: ${AppPreferences.firstRun}")
        }

        findViewById<Button>(R.id.my_ingredients_button).setOnClickListener {


            val intent = Intent(this, MyIngredientListActivity::class.java)
            startActivity(intent)
        }

    }
}