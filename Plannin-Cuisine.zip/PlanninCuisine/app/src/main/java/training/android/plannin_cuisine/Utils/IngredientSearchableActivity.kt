package training.android.plannin_cuisine.Utils

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.ArrayAdapter
import android.widget.ListView
import android.widget.SearchView
import android.widget.Toast
import androidx.appcompat.view.menu.MenuView
import training.android.plannin_cuisine.Database.App.Companion.database
import training.android.plannin_cuisine.Entities.Ingredient
import training.android.plannin_cuisine.R

class IngredientSearchableActivity : AppCompatActivity() {

    lateinit var searchView: SearchView
    lateinit var listView: ListView
    lateinit var list: ArrayList<String>
    private lateinit var adapter: ArrayAdapter<*>

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.ingredient_search_activity)

        val allIngredient = database.getAllIngredient()
        list = arrayListOf<String>()

        for (ingredient in allIngredient) {
            list.add(ingredient.name.toLowerCase())
        }

        listView = findViewById(R.id.activity_ingredient_searchable_listView)
        searchView = findViewById(R.id.activity_ingredient_searchable_searchView)

        adapter = ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, list)
        listView.adapter = adapter


        searchView.setOnQueryTextListener(object : SearchView.OnQueryTextListener {
            override fun onQueryTextSubmit(query: String?): Boolean {
                if (list.contains(query)) {
                    adapter.filter.filter(query)

                    listView.setOnItemClickListener { _, _, _, _ ->

                        Toast.makeText(this@IngredientSearchableActivity, "Izi", Toast.LENGTH_SHORT).show()
                    }

                } else {
                    Toast.makeText(
                        this@IngredientSearchableActivity,
                        "No Match found",
                        Toast.LENGTH_SHORT
                    ).show()
                }
                return false
            }

            override fun onQueryTextChange(newText: String?): Boolean {

                return false
            }
        })

        listView.setOnItemClickListener { parent, view, position, id ->

            Toast.makeText(this@IngredientSearchableActivity, "Izi", Toast.LENGTH_SHORT).show()
        }


    }
}