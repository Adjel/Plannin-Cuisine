package training.android.plannin_cuisine

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity
import training.android.plannin_cuisine.Database.App
import training.android.plannin_cuisine.Utils.IngredientSearchableActivity

class MyIngredientListActivity: AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.my_ingredient_list_activity)

        findViewById<Button>(R.id.ingredient_list_activity_search_button).setOnClickListener {

            val intent = Intent(this, IngredientSearchableActivity::class.java)
            startActivity(intent)
        }


    }
}